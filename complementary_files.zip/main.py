## C13 Recursion
# EX8 - Eight Queens

import image
import ImageTK
from tkinter import *

SIZE = 8  # size of the chessboard



class EightQueens:
    def __init__(self):
        self.queens = SIZE * [-1]  # Queens positions
        self.search(0)  # search for a solution for row 0

        # display solution in queens
        window = Tk()
        window.title("Eight Queens")

        image = ImageTk.PhotoImage(Image.open("image/queen.png"))
        for i in range(SIZE):
            for j in range(SIZE):
                if self.queens[i] == j:
                    Label(window, image=image).grid(
                        row=i, column=j)
                else:
                    Label(window, width=5, height=2,
                          bg="red").grid(row=i, column=j)
        window.mainloop()

    def search(self, row):
        if row == SIZE:  # Stopping condition
            return True  # A solution found to place 8 queens

        for column in range(SIZE):
            self.queens[row] = column  # place it at (row, column)
            if self.is_valid(row, column) and self.search(row + 1):
                return True  # Found and exist for loop

            # No solution for a queen placed at any column of this row
            return False

    def is_valid(self, row, column):
        for i in range(1, row + 1):
            if (self.queens[row - i] == column  # Check column
                    or self.queens[row - i] == column - i
                    or self.queens[row - i] == column + i):
                return False  # There is a conflict
        return True  # there is no conflict


EightQueens()
